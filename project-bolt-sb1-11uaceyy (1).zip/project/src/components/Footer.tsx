import React from 'react';
import { Phone, Smartphone, MessageCircle, Mail, MapPin } from 'lucide-react';
import { motion } from 'framer-motion';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-br from-primary-800 to-primary-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-4"
          >
            <img
              src="https://i.postimg.cc/x8zq9Qvf/2025-06-29-T075316-796.png"
              alt="ON AFRICA TP Logo"
              className="h-16 w-auto brightness-0 invert"
            />
            <p className="text-gray-200 text-sm leading-relaxed">
              Spécialiste en BTP, logistique et travaux publics. 
              Construire l'Afrique de demain, aujourd'hui.
            </p>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="space-y-4"
          >
            <h3 className="text-lg font-semibold">Liens rapides</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="/presentation" className="text-gray-200 hover:text-white transition-colors">Présentation</a></li>
              <li><a href="/mot-du-directeur" className="text-gray-200 hover:text-white transition-colors">Le mot du directeur</a></li>
              <li><a href="/services" className="text-gray-200 hover:text-white transition-colors">Nos services</a></li>
              <li><a href="/realisations" className="text-gray-200 hover:text-white transition-colors">Réalisations</a></li>
            </ul>
          </motion.div>

          {/* Services */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-4"
          >
            <h3 className="text-lg font-semibold">Nos services</h3>
            <ul className="space-y-2 text-sm text-gray-200">
              <li>Construction de bâtiments</li>
              <li>Terrassement et voirie</li>
              <li>Aménagements agricoles</li>
              <li>Logistique et transport</li>
            </ul>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="space-y-4"
          >
            <h3 className="text-lg font-semibold">Contact</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-3">
                <Phone size={16} className="text-accent-300" />
                <span className="text-gray-200">+222 25901252</span>
              </div>
              <div className="flex items-center space-x-3">
                <Smartphone size={16} className="text-accent-300" />
                <span className="text-gray-200">+222 28880729</span>
              </div>
              <div className="flex items-center space-x-3">
                <MessageCircle size={16} className="text-accent-300" />
                <span className="text-gray-200">+34 666 39 63 36</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin size={16} className="text-accent-300" />
                <span className="text-gray-200">BP: 06992</span>
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="border-t border-primary-700 mt-8 pt-8 text-center"
        >
          <p className="text-gray-200 text-sm">
            © 2025 ON AFRICA TP.sarl. Tous droits réservés.
          </p>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;