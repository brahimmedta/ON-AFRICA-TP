import React from 'react';
import { motion } from 'framer-motion';

interface BackgroundShapesProps {
  variant?: 'default' | 'minimal' | 'complex';
}

const BackgroundShapes: React.FC<BackgroundShapesProps> = ({ variant = 'default' }) => {
  const shapes = {
    default: [
      {
        className: 'bg-shape bg-shape-1',
        style: { top: '10%', right: '10%' },
        animate: { y: [-20, 20, -20], rotate: [0, 5, 0] },
        transition: { duration: 15, repeat: Infinity, ease: "easeInOut" }
      },
      {
        className: 'bg-shape bg-shape-2',
        style: { bottom: '20%', left: '5%' },
        animate: { y: [20, -20, 20], rotate: [0, -5, 0] },
        transition: { duration: 12, repeat: Infinity, ease: "easeInOut", delay: 2 }
      },
      {
        className: 'bg-shape bg-shape-3',
        style: { top: '50%', right: '5%' },
        animate: { rotate: [0, 360] },
        transition: { duration: 25, repeat: Infinity, ease: "linear" }
      }
    ],
    minimal: [
      {
        className: 'bg-shape',
        style: { 
          top: '15%', 
          right: '15%',
          width: '120px',
          height: '120px',
          background: 'linear-gradient(135deg, #0a2f6d, #0052cc)',
          borderRadius: '50%',
          opacity: 0.08
        },
        animate: { y: [-15, 15, -15] },
        transition: { duration: 10, repeat: Infinity, ease: "easeInOut" }
      },
      {
        className: 'bg-shape',
        style: { 
          bottom: '25%', 
          left: '10%',
          width: '80px',
          height: '80px',
          background: 'linear-gradient(45deg, #0052cc, #3385ff)',
          borderRadius: '30%',
          opacity: 0.06
        },
        animate: { y: [15, -15, 15], rotate: [0, 10, 0] },
        transition: { duration: 8, repeat: Infinity, ease: "easeInOut", delay: 1 }
      }
    ],
    complex: [
      {
        className: 'bg-shape',
        style: { 
          top: '5%', 
          right: '8%',
          width: '180px',
          height: '180px',
          background: 'conic-gradient(from 0deg, #0a2f6d, #0052cc, #3385ff, #0a2f6d)',
          borderRadius: '50%',
          opacity: 0.1
        },
        animate: { rotate: [0, 360], scale: [1, 1.1, 1] },
        transition: { duration: 20, repeat: Infinity, ease: "linear" }
      },
      {
        className: 'bg-shape',
        style: { 
          bottom: '15%', 
          left: '3%',
          width: '140px',
          height: '140px',
          background: 'linear-gradient(45deg, #0052cc, #66a3ff)',
          clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
          opacity: 0.08
        },
        animate: { y: [20, -20, 20], rotate: [0, 15, 0] },
        transition: { duration: 14, repeat: Infinity, ease: "easeInOut", delay: 3 }
      },
      {
        className: 'bg-shape',
        style: { 
          top: '40%', 
          right: '2%',
          width: '100px',
          height: '100px',
          background: 'linear-gradient(225deg, #3385ff, #99c2ff)',
          borderRadius: '30% 70% 70% 30% / 30% 30% 70% 70%',
          opacity: 0.07
        },
        animate: { y: [-10, 10, -10], rotate: [0, -10, 0] },
        transition: { duration: 16, repeat: Infinity, ease: "easeInOut", delay: 1.5 }
      }
    ]
  };

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {shapes[variant].map((shape, index) => (
        <motion.div
          key={index}
          className={shape.className}
          style={shape.style}
          animate={shape.animate}
          transition={shape.transition}
        />
      ))}
    </div>
  );
};

export default BackgroundShapes;