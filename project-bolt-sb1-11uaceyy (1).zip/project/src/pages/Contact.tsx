import React from 'react';
import { MapPin, Phone, Mail, Clock, MessageCircle, Smartphone } from 'lucide-react';
import { motion } from 'framer-motion';

const Contact = () => {
  const contactInfo = [
    {
      icon: <Phone className="h-6 w-6" />,
      title: 'Téléphone',
      details: '+222 25901252',
    },
    {
      icon: <Smartphone className="h-6 w-6" />,
      title: 'Mobile',
      details: '+222 28880729',
    },
    {
      icon: <MessageCircle className="h-6 w-6" />,
      title: 'WhatsApp',
      details: '+34 666 39 63 36',
    },
    {
      icon: <MapPin className="h-6 w-6" />,
      title: 'BP',
      details: '06992',
    },
    {
      icon: <Clock className="h-6 w-6" />,
      title: 'Horaires',
      details: 'Lun - Ven: 8h00 - 18h00',
    },
  ];

  return (
    <div id="contact" className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary-900 to-primary-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl lg:text-6xl font-bold mb-6">
              Contactez
              <span className="text-accent-400"> Nous</span>
            </h1>
            <p className="text-xl lg:text-2xl text-primary-200 max-w-4xl mx-auto">
              Nous sommes là pour répondre à vos questions et étudier vos projets
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-primary-900 mb-6">
              Informations de contact
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              N'hésitez pas à nous contacter pour discuter de vos projets. 
              Notre équipe est disponible pour vous accompagner et vous conseiller.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {contactInfo.map((info, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-gray-50 p-8 rounded-2xl hover:shadow-xl transition-all duration-300 card-3d text-center"
              >
                <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center text-primary-600 mx-auto mb-6">
                  {info.icon}
                </div>
                <h3 className="font-semibold text-primary-900 text-lg mb-2">{info.title}</h3>
                <p className="text-gray-600 text-lg">{info.details}</p>
              </motion.div>
            ))}
          </div>

          {/* Quick Contact */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="bg-primary-900 p-8 rounded-2xl text-white mt-16 max-w-4xl mx-auto"
          >
            <h3 className="text-2xl font-bold mb-4 text-center">Contact rapide</h3>
            <p className="text-primary-200 mb-6 text-center">
              Pour une réponse immédiate, contactez-nous directement :
            </p>
            <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-8">
              <a
                href="tel:+22225901252"
                className="flex items-center space-x-3 text-accent-400 hover:text-accent-300 transition-colors"
              >
                <Phone className="h-5 w-5" />
                <span className="font-semibold">+222 25901252</span>
              </a>
              <a
                href="https://wa.me/34666396336"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-3 text-accent-400 hover:text-accent-300 transition-colors"
              >
                <MessageCircle className="h-5 w-5" />
                <span className="font-semibold">WhatsApp: +34 666 39 63 36</span>
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-3xl lg:text-4xl font-bold text-primary-900 mb-6">
              Prêt à démarrer votre projet ?
            </h3>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Notre équipe d'experts est prête à vous accompagner dans la réalisation 
              de vos projets les plus ambitieux.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="tel:+22225901252"
                className="inline-flex items-center px-6 py-3 bg-primary-600 text-white font-semibold rounded-full hover:bg-primary-700 transition-all duration-300 btn-3d"
              >
                <Phone className="mr-2 h-5 w-5" />
                Appeler maintenant
              </a>
              <a
                href="https://wa.me/34666396336"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-6 py-3 bg-green-600 text-white font-semibold rounded-full hover:bg-green-700 transition-all duration-300 btn-3d"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                WhatsApp
              </a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Contact;