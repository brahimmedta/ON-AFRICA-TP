import React from 'react';
import { Quote } from 'lucide-react';
import { motion } from 'framer-motion';

const DirectorMessage = () => {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary-900 to-primary-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl lg:text-6xl font-bold mb-6">
              Le mot du
              <span className="text-accent-400"> Directeur</span>
            </h1>
            <p className="text-xl lg:text-2xl text-primary-200 max-w-4xl mx-auto">
              Vision et engagement pour l'avenir de ON AFRICA TP
            </p>
          </motion.div>
        </div>
      </section>

      {/* Director Message */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Director Photos */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              {/* First Director Image */}
              <div className="relative overflow-hidden rounded-2xl shadow-2xl">
                <img
                  src="https://i.postimg.cc/HLwm2xp1/9d4f801b-36c6-452a-88f9-8a2d86c94d3c.jpg"
                  alt="Directeur de ON AFRICA TP"
                  className="w-full h-auto object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary-900/20 to-transparent"></div>
              </div>
              
              {/* Second Director Image */}
              <div className="relative overflow-hidden rounded-2xl shadow-2xl">
                <img
                  src="https://i.postimg.cc/HLwm2xp1/9d4f801b-36c6-452a-88f9-8a2d86c94d3c.jpg"
                  alt="Directeur de ON AFRICA TP - Portrait"
                  className="w-full h-auto object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary-900/20 to-transparent"></div>
              </div>
              
              {/* Decorative Elements */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-accent-400 rounded-full opacity-20 animate-float"></div>
              <div className="absolute -bottom-6 -left-6 w-16 h-16 bg-primary-600 rounded-full opacity-30 animate-float" style={{ animationDelay: '2s' }}></div>
            </motion.div>

            {/* Message Content */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              <div className="flex items-start space-x-4">
                <Quote className="h-12 w-12 text-primary-600 flex-shrink-0 mt-2" />
                <div className="space-y-6 text-gray-700 text-lg leading-relaxed">
                  <p>
                    Chers partenaires, clients et collaborateurs,
                  </p>
                  
                  <p>
                    Depuis la création de ON AFRICA TP en 2009, notre vision a toujours été claire : 
                    <strong className="text-primary-900"> construire l'Afrique de demain, aujourd'hui</strong>. 
                    Cette mission guide chacune de nos actions et inspire notre engagement quotidien.
                  </p>

                  <p>
                    Au fil des années, nous avons su nous imposer comme un acteur de référence 
                    dans les domaines du BTP, de la logistique et des travaux publics. 
                    Cette réussite, nous la devons à la confiance que vous nous accordez, 
                    mais aussi à l'excellence de nos équipes et à notre approche innovante.
                  </p>

                  <p>
                    Dans un continent en pleine transformation, nous continuons d'investir 
                    dans les technologies les plus avancées et dans la formation de nos équipes 
                    pour vous offrir des solutions toujours plus performantes et durables.
                  </p>

                  <p>
                    Notre engagement va au-delà de la simple réalisation de projets. 
                    Nous participons activement au développement économique et social 
                    de nos communautés, en privilégiant les emplois locaux et 
                    les pratiques respectueuses de l'environnement.
                  </p>

                  <p>
                    Je tiens à remercier tous nos partenaires qui nous font confiance 
                    et nos collaborateurs qui s'investissent quotidiennement pour 
                    maintenir notre niveau d'excellence.
                  </p>

                  <p className="font-semibold text-primary-900">
                    Ensemble, continuons à bâtir l'Afrique de demain !
                  </p>
                </div>
              </div>

              {/* Signature */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="pt-8 border-t border-gray-200"
              >
                <div className="text-right">
                  <p className="font-semibold text-primary-900 text-xl">Directeur Général</p>
                  <p className="text-gray-600">ON AFRICA TP.sarl</p>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Leadership Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-primary-900 mb-6">
              Leadership et Vision
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Les principes qui guident notre direction vers l'excellence
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'Innovation',
                description: 'Adoption constante des dernières technologies et méthodes pour rester à la pointe de notre secteur.',
                color: 'bg-blue-100 text-blue-600',
              },
              {
                title: 'Responsabilité',
                description: 'Engagement envers nos communautés et respect de l\'environnement dans tous nos projets.',
                color: 'bg-green-100 text-green-600',
              },
              {
                title: 'Excellence',
                description: 'Recherche permanente de la qualité et dépassement des attentes de nos clients.',
                color: 'bg-purple-100 text-purple-600',
              },
            ].map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="bg-white p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 card-3d"
              >
                <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-6 ${value.color}`}>
                  <Quote className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-primary-900 mb-4">
                  {value.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default DirectorMessage;