import React, { useState } from 'react';
import { X, ZoomIn } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const Projects = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleContactClick = () => {
    navigate('/contact');
  };

  const projects = [
    {
      id: 1,
      title: 'Projet de construction moderne',
      category: 'Construction',
      image: 'https://i.postimg.cc/Y25wJYhB/62fc8b03-29dc-443c-be5f-1170b94fc960.jpg',
      description: 'Réalisation d\'un complexe résidentiel moderne avec standards internationaux.',
    },
    {
      id: 2,
      title: 'Infrastructure routière',
      category: 'Travaux publics',
      image: 'https://i.postimg.cc/5yvDxK6d/deba58d9-da5f-4f0f-87c2-448db6d3ecee.jpg',
      description: 'Aménagement et construction de routes avec équipements de pointe.',
    },
    {
      id: 3,
      title: 'Aménagement urbain',
      category: 'Aménagement',
      image: 'https://i.postimg.cc/7hgQvCWq/5937acb7-17a5-4904-90fb-2c96f91192db.jpg',
      description: 'Projet d\'aménagement urbain intégrant espaces verts et infrastructures modernes.',
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary-900 to-primary-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl lg:text-6xl font-bold mb-6">
              Nos
              <span className="text-accent-400"> Réalisations</span>
            </h1>
            <p className="text-xl lg:text-2xl text-primary-200 max-w-4xl mx-auto">
              Découvrez nos projets les plus emblématiques et notre savoir-faire
            </p>
          </motion.div>
        </div>
      </section>

      {/* Projects Gallery */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-primary-900 mb-6">
              Portfolio de nos projets
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Chaque projet reflète notre engagement envers l'excellence et l'innovation
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="group cursor-pointer"
                onClick={() => setSelectedImage(project.image)}
              >
                <div className="relative overflow-hidden rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 card-3d">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-primary-900/80 via-primary-900/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="absolute bottom-6 left-6 right-6 text-white">
                      <div className="flex items-center justify-between mb-2">
                        <span className="px-3 py-1 bg-accent-500 text-xs font-semibold rounded-full">
                          {project.category}
                        </span>
                        <ZoomIn className="h-6 w-6" />
                      </div>
                      <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                      <p className="text-primary-200 text-sm">{project.description}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90"
            onClick={() => setSelectedImage(null)}
          >
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              className="relative max-w-4xl max-h-full"
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={selectedImage}
                alt="Projet sélectionné"
                className="max-w-full max-h-full object-contain rounded-lg"
              />
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute top-4 right-4 p-2 bg-white/20 hover:bg-white/30 rounded-full text-white transition-colors"
              >
                <X size={24} />
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Expertise Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-3xl lg:text-4xl font-bold text-primary-900 mb-6">
                Une expertise qui fait la différence
              </h2>
              <div className="space-y-6 text-gray-600 text-lg leading-relaxed">
                <p>
                  Chaque projet que nous réalisons témoigne de notre engagement 
                  envers l'excellence et l'innovation. Notre approche combine 
                  savoir-faire traditionnel et technologies de pointe.
                </p>
                <p>
                  De la conception à la livraison, nous accompagnons nos clients 
                  avec professionnalisme et transparence, garantissant des résultats 
                  qui dépassent leurs attentes.
                </p>
                <p>
                  Notre portfolio diversifié illustre notre capacité à nous adapter 
                  aux défis les plus complexes tout en respectant les délais 
                  et les budgets convenus.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="grid grid-cols-2 gap-4"
            >
              {[
                { number: '500+', label: 'Projets réalisés' },
                { number: '16+', label: 'Années d\'expérience' },
                { number: '100+', label: 'Clients satisfaits' },
                { number: '98%', label: 'Taux de satisfaction' },
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.5 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-white p-6 rounded-2xl shadow-xl text-center card-3d"
                >
                  <div className="text-3xl lg:text-4xl font-bold text-primary-600 mb-2">
                    {stat.number}
                  </div>
                  <div className="text-gray-600 text-sm">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-3xl lg:text-4xl font-bold mb-6">
              Votre prochain projet nous attend
            </h3>
            <p className="text-xl text-primary-200 mb-8 max-w-3xl mx-auto">
              Transformons ensemble vos idées en réalisations concrètes. 
              Contactez-nous pour démarrer votre projet.
            </p>
            <button
              onClick={handleContactClick}
              className="inline-flex items-center px-8 py-4 bg-accent-500 text-white text-lg font-semibold rounded-full hover:bg-accent-600 transition-all duration-300 btn-3d cursor-pointer"
            >
              Démarrer un projet
            </button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Projects;