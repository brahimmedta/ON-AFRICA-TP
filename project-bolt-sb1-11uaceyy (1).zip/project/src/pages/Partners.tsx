import React from 'react';
import { Handshake, Users, Target, Award } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import BackgroundShapes from '../components/BackgroundShapes';

const Partners = () => {
  const navigate = useNavigate();

  const handleContactClick = () => {
    navigate('/contact');
  };

  // Sample partner companies data - this will be managed via CMS
  const partnerCompanies = [
    {
      id: 1,
      name: 'Partenaire Stratégique A',
      logo: 'https://i.postimg.cc/gjq4SCxJ/da350119-b01a-44e8-8078-ca0b1a7e48c2.jpg',
      description: 'Leader dans les solutions de construction moderne et durable.',
    },
    {
      id: 2,
      name: 'Groupe International B',
      logo: 'https://i.postimg.cc/gjq4SCxJ/da350119-b01a-44e8-8078-ca0b1a7e48c2.jpg',
      description: 'Spécialiste en équipements lourds et logistique industrielle.',
    },
    {
      id: 3,
      name: 'Entreprise Technique C',
      logo: 'https://i.postimg.cc/gjq4SCxJ/da350119-b01a-44e8-8078-ca0b1a7e48c2.jpg',
      description: 'Expertise en travaux publics et aménagement urbain.',
    },
    {
      id: 4,
      name: 'Partenaire Innovation D',
      logo: 'https://i.postimg.cc/gjq4SCxJ/da350119-b01a-44e8-8078-ca0b1a7e48c2.jpg',
      description: 'Solutions technologiques avancées pour le secteur BTP.',
    },
    {
      id: 5,
      name: 'Groupe Logistique E',
      logo: 'https://i.postimg.cc/gjq4SCxJ/da350119-b01a-44e8-8078-ca0b1a7e48c2.jpg',
      description: 'Transport et logistique internationale de premier plan.',
    },
    {
      id: 6,
      name: 'Entreprise Durable F',
      logo: 'https://i.postimg.cc/gjq4SCxJ/da350119-b01a-44e8-8078-ca0b1a7e48c2.jpg',
      description: 'Solutions écologiques et développement durable.',
    },
    {
      id: 7,
      name: 'Partenaire Régional G',
      logo: 'https://i.postimg.cc/gjq4SCxJ/da350119-b01a-44e8-8078-ca0b1a7e48c2.jpg',
      description: 'Acteur majeur du développement régional africain.',
    },
    {
      id: 8,
      name: 'Groupe Excellence H',
      logo: 'https://i.postimg.cc/gjq4SCxJ/da350119-b01a-44e8-8078-ca0b1a7e48c2.jpg',
      description: 'Standards d\'excellence en ingénierie et construction.',
    },
  ];

  const partnerBenefits = [
    {
      icon: <Handshake className="h-8 w-8" />,
      title: 'Partenariats durables',
      description: 'Relations de confiance basées sur la transparence et le respect mutuel.',
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: 'Collaboration étroite',
      description: 'Travail en équipe pour atteindre des objectifs communs d\'excellence.',
    },
    {
      icon: <Target className="h-8 w-8" />,
      title: 'Objectifs partagés',
      description: 'Vision commune du développement durable en Afrique.',
    },
    {
      icon: <Award className="h-8 w-8" />,
      title: 'Standards élevés',
      description: 'Exigence de qualité et respect des normes internationales.',
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-primary-900 to-primary-800 text-white overflow-hidden">
        <BackgroundShapes variant="complex" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl lg:text-6xl font-bold mb-6">
              Nos
              <span className="text-accent-400"> Partenaires</span>
            </h1>
            <p className="text-xl lg:text-2xl text-primary-200 max-w-4xl mx-auto">
              Ensemble, nous construisons l'avenir de l'Afrique
            </p>
          </motion.div>
        </div>
      </section>

      {/* Partner Companies Grid - 4 columns */}
      <section className="relative py-20 bg-white overflow-hidden">
        <BackgroundShapes variant="minimal" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-primary-900 mb-6">
              Ils nous font confiance
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Des partenariats stratégiques qui renforcent notre capacité 
              à livrer des projets d'excellence
            </p>
          </motion.div>

          {/* 4-column responsive grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {partnerCompanies.map((partner, index) => (
              <motion.div
                key={partner.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 card-3d overflow-hidden group"
              >
                {/* Partner Logo */}
                <div className="h-32 bg-gray-50 flex items-center justify-center p-4">
                  <img
                    src={partner.logo}
                    alt={`Logo ${partner.name}`}
                    className="max-h-full max-w-full object-contain group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                
                {/* Partner Info */}
                <div className="p-6">
                  <h3 className="text-lg font-bold text-primary-800 mb-3 text-center">
                    {partner.name}
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed text-center">
                    {partner.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Partnership Benefits */}
      <section className="relative py-20 bg-gray-50 overflow-hidden">
        <BackgroundShapes variant="default" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-primary-900 mb-6">
              Pourquoi choisir ON AFRICA TP ?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Les avantages de notre approche partenariale
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {partnerBenefits.map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="bg-white p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 card-3d text-center"
              >
                <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mb-6 mx-auto text-primary-600">
                  {benefit.icon}
                </div>
                <h3 className="text-lg font-semibold text-primary-900 mb-4">
                  {benefit.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {benefit.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Partnership Values */}
      <section className="relative py-20 bg-white overflow-hidden">
        <BackgroundShapes variant="minimal" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-3xl lg:text-4xl font-bold text-primary-900 mb-6">
                Des partenariats qui créent de la valeur
              </h2>
              <div className="space-y-6 text-gray-600 text-lg leading-relaxed">
                <p>
                  Nos partenariats ne se limitent pas à des relations commerciales. 
                  Ils représentent un engagement mutuel vers l'excellence et 
                  l'innovation dans tous nos projets.
                </p>
                <p>
                  Chaque partenaire apporte son expertise unique, créant une 
                  synergie qui bénéficie directement à nos clients et aux 
                  communautés que nous servons.
                </p>
                <p>
                  Ensemble, nous développons des solutions durables qui 
                  contribuent au développement économique et social de l'Afrique.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              {[
                {
                  title: 'Confiance mutuelle',
                  description: 'Relations basées sur la transparence et le respect des engagements',
                  percentage: '98%',
                },
                {
                  title: 'Innovation partagée',
                  description: 'Développement conjoint de solutions innovantes',
                  percentage: '95%',
                },
                {
                  title: 'Croissance commune',
                  description: 'Succès partagé et développement durable',
                  percentage: '92%',
                },
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  className="bg-gray-50 p-6 rounded-xl"
                >
                  <div className="flex justify-between items-start mb-3">
                    <h4 className="font-semibold text-primary-900">{item.title}</h4>
                    <span className="text-2xl font-bold text-primary-600">{item.percentage}</span>
                  </div>
                  <p className="text-gray-600 text-sm">{item.description}</p>
                  <div className="mt-3 w-full bg-gray-200 rounded-full h-2">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: item.percentage }}
                      transition={{ duration: 1, delay: index * 0.2 }}
                      className="bg-primary-600 h-2 rounded-full"
                    ></motion.div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 bg-gradient-to-br from-primary-800 to-primary-900 text-white overflow-hidden">
        <BackgroundShapes variant="complex" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-3xl lg:text-4xl font-bold mb-6">
              Devenez notre partenaire
            </h3>
            <p className="text-xl text-primary-200 mb-8 max-w-3xl mx-auto">
              Rejoignez notre réseau de partenaires et participez ensemble 
              au développement de l'Afrique de demain.
            </p>
            <button
              onClick={handleContactClick}
              className="inline-flex items-center px-8 py-4 bg-accent-500 text-white text-lg font-semibold rounded-full hover:bg-accent-600 transition-all duration-300 btn-3d cursor-pointer"
            >
              Nous contacter
            </button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Partners;