import React from 'react';
import { Building2, Truck, Wrench, Droplets, MapPin, Settings, Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const Services = () => {
  const navigate = useNavigate();

  const handleContactClick = () => {
    navigate('/contact');
  };

  const services = [
    {
      icon: <Building2 className="h-8 w-8" />,
      title: 'Construction de bâtiments',
      description: 'Conception et réalisation de projets de construction résidentiels, commerciaux et industriels avec les standards de qualité les plus élevés.',
      image: 'https://i.postimg.cc/QCPvsGXq/c981b834-9f70-42e7-89a1-b3782ac32dd0.jpg',
    },
    {
      icon: <Wrench className="h-8 w-8" />,
      title: 'Terrassement et voirie',
      description: 'Travaux de terrassement, construction de routes, aménagement de voies d\'accès et infrastructure routière complète.',
      image: 'https://i.postimg.cc/Rh3bgscJ/05cc3b44-ddaf-4ce0-8807-13ba8aec1c0d.jpg',
    },
    {
      icon: <MapPin className="h-8 w-8" />,
      title: 'Aménagements agricoles',
      description: 'Développement d\'infrastructures agricoles modernes pour optimiser la production et améliorer les rendements.',
      image: 'https://i.postimg.cc/0y1HCCrr/6f1f99f5-afd3-4dfc-ac3f-1f5020092a4d.jpg',
    },
    {
      icon: <Droplets className="h-8 w-8" />,
      title: 'Adduction d\'eau potable',
      description: 'Conception et installation de systèmes d\'approvisionnement en eau potable pour les communautés et industries.',
      image: 'https://i.postimg.cc/Rh3bgscJ/05cc3b44-ddaf-4ce0-8807-13ba8aec1c0d.jpg',
    },
    {
      icon: <Truck className="h-8 w-8" />,
      title: 'Logistique et transport',
      description: 'Solutions complètes de transport et logistique pour tous types de marchandises et équipements.',
      image: 'https://i.postimg.cc/0y1HCCrr/6f1f99f5-afd3-4dfc-ac3f-1f5020092a4d.jpg',
    },
    {
      icon: <Settings className="h-8 w-8" />,
      title: 'Location de camions et engins lourds',
      description: 'Parc moderne d\'équipements lourds disponibles à la location avec service de maintenance inclus.',
      image: 'https://i.postimg.cc/QCPvsGXq/c981b834-9f70-42e7-89a1-b3782ac32dd0.jpg',
    },
    {
      icon: <Plus className="h-8 w-8" />,
      title: 'Autres services',
      description: 'Services personnalisés adaptés aux besoins spécifiques de chaque client et projet.',
    },
  ];

  const values = [
    {
      emoji: '🎯',
      title: 'Mission',
      description: 'Fournir des solutions fiables et innovantes dans le domaine du BTP, de la logistique et des travaux publics.',
    },
    {
      emoji: '👁',
      title: 'Vision',
      description: 'Être reconnu comme le partenaire de confiance incontournable pour tous les projets en Afrique.',
    },
    {
      emoji: '💡',
      title: 'Valeurs',
      description: 'Professionnalisme – Intégrité – Sécurité : les piliers de notre excellence.',
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary-900 to-primary-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl lg:text-6xl font-bold mb-6">
              Nos
              <span className="text-accent-400"> Services</span>
            </h1>
            <p className="text-xl lg:text-2xl text-primary-200 max-w-4xl mx-auto">
              Des solutions complètes et innovantes pour tous vos projets
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 card-3d overflow-hidden group"
              >
                {service.image && (
                  <div className="h-48 overflow-hidden">
                    <img
                      src={service.image}
                      alt={service.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                )}
                
                <div className="p-8">
                  <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mb-6 text-primary-600 group-hover:bg-primary-600 group-hover:text-white transition-colors duration-300">
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-primary-900 mb-4">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {service.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-primary-900 mb-6">
              Notre engagement
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Les valeurs qui guident notre action quotidienne
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="bg-white p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 card-3d text-center"
              >
                <div className="text-6xl mb-6">
                  {value.emoji}
                </div>
                <h3 className="text-2xl font-bold text-primary-900 mb-4">
                  {value.title}
                </h3>
                <p className="text-gray-600 leading-relaxed text-lg">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-3xl lg:text-4xl font-bold mb-6">
              Prêt à démarrer votre projet ?
            </h3>
            <p className="text-xl text-primary-200 mb-8 max-w-3xl mx-auto">
              Contactez-nous dès aujourd'hui pour discuter de vos besoins et obtenir un devis personnalisé.
            </p>
            <button
              onClick={handleContactClick}
              className="inline-flex items-center px-8 py-4 bg-accent-500 text-white text-lg font-semibold rounded-full hover:bg-accent-600 transition-all duration-300 btn-3d cursor-pointer"
            >
              Demander un devis
            </button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Services;