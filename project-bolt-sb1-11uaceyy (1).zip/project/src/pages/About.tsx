import React from 'react';
import { CheckCircle, Target, Eye, Heart } from 'lucide-react';
import { motion } from 'framer-motion';
import AnimatedCounter from '../components/AnimatedCounter';
import BackgroundShapes from '../components/BackgroundShapes';

const About = () => {
  const values = [
    {
      icon: <CheckCircle className="h-8 w-8" />,
      title: 'Professionnalisme',
      description: 'Excellence technique et respect des délais dans tous nos projets.',
    },
    {
      icon: <Heart className="h-8 w-8" />,
      title: 'Intégrité',
      description: 'Transparence et honnêteté dans toutes nos relations d\'affaires.',
    },
    {
      icon: <Target className="h-8 w-8" />,
      title: 'Sécurité',
      description: 'Priorité absolue à la sécurité de nos équipes et de nos clients.',
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-primary-800 to-primary-900 text-white overflow-hidden">
        <BackgroundShapes variant="complex" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl lg:text-6xl font-bold mb-6">
              Présentation de
              <span className="text-accent-400"> ON AFRICA TP</span>
            </h1>
            <p className="text-xl lg:text-2xl text-gray-200 max-w-4xl mx-auto">
              Une entreprise fondée en 2009, spécialisée dans le BTP, la logistique et les travaux publics
            </p>
          </motion.div>
        </div>
      </section>

      {/* Company Story */}
      <section className="relative py-20 bg-white overflow-hidden">
        <BackgroundShapes variant="minimal" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-3xl lg:text-4xl font-bold text-primary-800 mb-6">
                Notre histoire
              </h2>
              <div className="space-y-6 text-gray-600 leading-relaxed">
                <p className="text-lg">
                  Fondée en 2009, ON AFRICA TP.sarl s'est imposée comme un acteur majeur 
                  du secteur du BTP en Afrique. Notre entreprise a été créée avec la vision 
                  de contribuer au développement durable du continent africain.
                </p>
                <p className="text-lg">
                  Spécialisée dans la construction, la logistique et les travaux publics, 
                  nous offrons des solutions complètes et innovantes adaptées aux défis 
                  spécifiques du marché africain.
                </p>
                <p className="text-lg">
                  Avec plus de 16 ans d'expérience, nous avons développé une expertise 
                  reconnue et bâti une réputation solide basée sur la qualité, 
                  la fiabilité et l'innovation.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <img
                src="https://i.postimg.cc/xjbwy8gx/b79e808c-d204-4333-8ad3-06938df561de.jpg"
                alt="ON AFRICA TP - Notre équipe au travail"
                className="rounded-2xl shadow-2xl w-full h-auto"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary-800/20 to-transparent rounded-2xl"></div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="relative py-20 bg-gray-50 overflow-hidden">
        <BackgroundShapes variant="default" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Mission & Vision */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="bg-white p-8 rounded-2xl shadow-xl card-3d"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mb-6">
                <Target className="h-8 w-8 text-primary-700" />
              </div>
              <h3 className="text-2xl font-bold text-primary-800 mb-4">🎯 Notre Mission</h3>
              <p className="text-gray-600 text-lg leading-relaxed">
                Fournir des solutions fiables et innovantes dans le domaine du BTP, 
                de la logistique et des travaux publics, en contribuant activement 
                au développement durable de l'Afrique.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="bg-white p-8 rounded-2xl shadow-xl card-3d"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-accent-100 to-accent-200 rounded-full flex items-center justify-center mb-6">
                <Eye className="h-8 w-8 text-accent-700" />
              </div>
              <h3 className="text-2xl font-bold text-primary-800 mb-4">👁 Notre Vision</h3>
              <p className="text-gray-600 text-lg leading-relaxed">
                Être reconnu comme le partenaire de confiance incontournable 
                pour tous les projets de construction et d'infrastructures 
                en Afrique, synonyme de qualité et d'excellence.
              </p>
            </motion.div>
          </div>

          {/* Values */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h3 className="text-3xl lg:text-4xl font-bold text-primary-800 mb-6">
              💡 Nos Valeurs
            </h3>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Les principes fondamentaux qui guident chacune de nos actions
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="bg-white p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 card-3d text-center group"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mb-6 mx-auto text-primary-700 group-hover:bg-gradient-to-br group-hover:from-primary-600 group-hover:to-primary-700 group-hover:text-white transition-all duration-300">
                  {value.icon}
                </div>
                <h4 className="text-xl font-semibold text-primary-800 mb-4">
                  {value.title}
                </h4>
                <p className="text-gray-600 leading-relaxed">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Expertise Section with Animated Counters */}
      <section className="relative py-20 bg-gradient-to-br from-primary-800 to-primary-900 text-white overflow-hidden">
        <BackgroundShapes variant="complex" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-3xl lg:text-4xl font-bold mb-8">
              Une expertise reconnue
            </h3>
            <p className="text-xl text-gray-200 max-w-4xl mx-auto mb-12">
              Avec plus de 500 projets réalisés et une équipe de professionnels expérimentés, 
              nous sommes fiers de contribuer au développement de l'Afrique.
            </p>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {[
                { number: 16, label: 'Années d\'expérience', suffix: '+' },
                { number: 500, label: 'Projets réalisés', suffix: '+' },
                { number: 100, label: 'Clients satisfaits', suffix: '+' },
                { number: 50, label: 'Employés qualifiés', suffix: '+' },
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.5 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="space-y-4 p-6 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 card-3d"
                >
                  <div className="text-4xl lg:text-5xl font-bold">
                    <AnimatedCounter
                      end={stat.number}
                      suffix={stat.suffix}
                      className="text-accent-300"
                    />
                  </div>
                  <div className="text-gray-200 text-sm lg:text-base font-medium">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default About;