import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Building2, Truck, Wrench } from 'lucide-react';
import { motion } from 'framer-motion';
import AnimatedCounter from '../components/AnimatedCounter';
import BackgroundShapes from '../components/BackgroundShapes';

const Home = () => {
  const services = [
    {
      icon: <Building2 className="h-8 w-8" />,
      title: 'Construction de bâtiments',
      description: 'Conception et réalisation de projets de construction modernes et durables.',
    },
    {
      icon: <Truck className="h-8 w-8" />,
      title: 'Logistique et transport',
      description: 'Solutions complètes de transport et logistique pour vos projets.',
    },
    {
      icon: <Wrench className="h-8 w-8" />,
      title: 'Travaux publics',
      description: 'Expertise en terrassement, voirie et aménagements urbains.',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section - Adjusted for always visible navigation */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden pt-24">
        <BackgroundShapes variant="complex" />
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://i.postimg.cc/wMfgmG9t/Whats-App-Image-2025-06-28-at-23-35-43.jpg')`,
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-primary-800/80 via-primary-800/70 to-primary-900/80"></div>
        </div>
        
        <div className="relative z-10 text-center text-white px-4 sm:px-6 lg:px-8">
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-4xl sm:text-6xl lg:text-7xl font-bold mb-6 text-shadow"
          >
            Construire l'Afrique
            <br />
            <span className="text-accent-400">de demain, aujourd'hui</span>
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl sm:text-2xl mb-8 max-w-3xl mx-auto text-gray-100"
          >
            Spécialiste en BTP, logistique et travaux publics depuis 2009. 
            Votre partenaire de confiance pour tous vos projets.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex justify-center"
          >
            <Link
              to="/presentation"
              className="inline-flex items-center px-8 py-4 bg-primary-600 text-white text-lg font-semibold rounded-full hover:bg-primary-700 transition-all duration-300 btn-3d group"
            >
              Découvrir notre mission
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
            <div className="w-1 h-3 bg-white rounded-full mt-2 animate-bounce"></div>
          </div>
        </motion.div>
      </section>

      {/* Services Preview */}
      <section className="relative py-20 bg-gray-50 overflow-hidden">
        <BackgroundShapes variant="minimal" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold text-primary-800 mb-6">
              Nos domaines d'expertise
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Des solutions complètes et innovantes pour répondre à tous vos besoins 
              en construction, logistique et travaux publics.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="bg-white p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 card-3d border border-gray-100 group"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mb-6 text-primary-700 group-hover:bg-gradient-to-br group-hover:from-primary-600 group-hover:to-primary-700 group-hover:text-white transition-all duration-300">
                  {service.icon}
                </div>
                <h3 className="text-xl font-semibold text-primary-800 mb-4">
                  {service.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {service.description}
                </p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="text-center mt-12"
          >
            <Link
              to="/services"
              className="inline-flex items-center px-6 py-3 bg-primary-600 text-white font-semibold rounded-full hover:bg-primary-700 transition-all duration-300 btn-3d"
            >
              Voir tous nos services
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Enhanced Stats Section with Animated Counters */}
      <section className="relative py-20 bg-gradient-to-br from-primary-800 to-primary-900 text-white overflow-hidden">
        <BackgroundShapes variant="default" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Notre expertise en chiffres
            </h2>
            <p className="text-xl text-gray-200 max-w-2xl mx-auto">
              Des résultats concrets qui témoignent de notre engagement
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { number: 16, label: 'Années d\'expérience', suffix: '+' },
              { number: 500, label: 'Projets réalisés', suffix: '+' },
              { number: 100, label: 'Clients satisfaits', suffix: '+' },
              { number: 24, label: 'Support disponible', suffix: '/7' },
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="space-y-4 p-6 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 card-3d"
              >
                <div className="text-4xl lg:text-6xl font-bold">
                  <AnimatedCounter
                    end={stat.number}
                    suffix={stat.suffix}
                    className="text-accent-300"
                  />
                </div>
                <div className="text-gray-200 text-sm lg:text-base font-medium">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;